#ifndef TASKS_H
  #define TASKS_H

void blink_lights();
void task0();
void task1();
void task2();

#endif