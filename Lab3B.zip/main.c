#include "types.h"
#include "tm4c123gh6pm.h"
#include "DIO.h"
#include "bitwise_operation.h"
#include <stdio.h>
#include <time.h>
#include "tasks.h"
#include "Keypad.h"
 


int main()
{
  
  KeyPad_Init();
  while(1)
  { 
    //printf("%d \n",x);
    SevenSegment_Display();
    delay(0.5);
  }
  return 0;
}

